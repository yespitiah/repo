import mongoose from  'mongoose';
const Schema =  mongoose.Schema;
import passportLocalMongoose  from 'passport-local-mongoose';

let entitlements  =  new Schema({
email: String,
permissions:  String
     });


entitlements.plugin(passportLocalMongoose);
module.exports = mongoose.model('entitlements', entitlements);
