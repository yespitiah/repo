var  mongoose  =  require('mongoose');
var  Schema =  mongoose.Schema;


var  sshCloudtrackerSchema =   new  Schema({
 host:String;
 alias:String;
 fid:String;
 sshkey:String;
})

module.exports =   mongoose.model('sshCloudtracker',sshCloudtrackerSchema);
