var  mongoose  =  require('mongoose');
var  Schema =  mongoose.Schema;


var  soids =   new  Schema({
 soid:String;
 name:String;
})

var trackerSchema = new Schema({
userid:[soids];
Type:String;
IssueDesc:String;
ResolutionDesc:String;
Description:String;
Owner:String;
Lob: String;
Date:String;
Severity:String;
NumberMIM:String;

})

module.exports =   mongoose.model('tracker',trackerSchema);
