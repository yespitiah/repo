#!/bin/bash
echo "Please provideService ServiceNow Ticket"
read  ticketNumber
echo "$ticketNumber" | egrep "INC|CTSK|CHG" >/dev/null
if [ $? -eq 0 ];then
if [ $? -eq 0 ];then
    v_host=`echo $@ | awk -F'@' '{print $2}'`
    v_soid=`echo $@ | awk -F'@' '{print $1}'`
    ticket=$ticketNumber
    exp="db.hostsInv.find({\"host\" : \""$v_host"\"}).map( function(u) { return u.alias})"
    answ=`mongo mongodb://127.0.0.1:27017/middlewarel2 --eval "$exp" --quiet`
    alias=`echo $answ | sed 's/\[ "//'|sed 's/\" ]//'`
    v_time="04-05-2018 12:00:12"
    exp="db.accessReport.insert({\"soid\":\""$v_soid"\",\"ticket\":\""$ticket"\",\"time\":\""$v_time"\"})"
    mongo mongodb://127.0.0.1:27017/middlewarel2 --quiet --eval "$exp" >/dev/null 
    echo "-------------------------"
    echo "Doing ssh $v_soid@$alias"
    ssh $v_soid@$alias
    fi    
else
echo "Ticket not  valid"
fi
