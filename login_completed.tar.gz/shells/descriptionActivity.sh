 #!/bin/bash
 v_platform=$1
 v_region=$2
 v_name=$3
 v_env=$4
 v_tabName=$5
 v_descriptionActivity=$6


 echo "ENTRO" 
 exp="db.applications.findOneAndUpdate({\"platform\":\""$v_platform"\",\"region\":\""$v_region"\",\"name\":\""$v_name"\",\"envs\":{\$elemMatch: {\"env\":\""$v_env"\"}}},{\$push:{\"envs.\$.mainactivities\":{\"nameActivity\" : \""$v_tabName"\",\"descriptionActivity\":\""$v_descriptionActivity"\"}}})"
 echo $exp
 mongo mongodb://127.0.0.1:27017/middlewarel2 --eval "$exp"
