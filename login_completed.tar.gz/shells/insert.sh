 #!/bin/bash

for   obj in  `cat file.txt`
do
 exp="db.entitlements.insert(${obj})"
 mongo mongodb://127.0.0.1:27017/middlewarel2 --eval "$exp"
done
