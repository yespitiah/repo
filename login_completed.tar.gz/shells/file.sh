 #!/bin/bash
 v_platform=$1
 v_region=$2
 v_name=$3
 v_env=$4
 v_number=$5
 v_descriptionActivity_1=$6
 v_descriptionActivity=`echo $v_descriptionActivity_1`
 

#exp="db.applications.findOneAndUpdate({\"platform\":\""$v_platform"\",\"region\":\""$v_region"\",\"name\":\""$v_name"\",\"envs\":{\$elemMatch: {\"env\":\""$v_env"\"}}},{\$set:{\"envs.\$.mainactivities."$v_number".descriptionActivity\":\""$v_descriptionActivity"\"}})"
exp="db.applications.findOneAndUpdate({\"platform\":\""$v_platform"\",\"region\":\""$v_region"\",\"name\":\""$v_name"\",\"envs\":{\$elemMatch: {\"env\":\""$v_env"\"}}},{\$set:{\"envs.\$.mainactivities."$v_number".descriptionActivity\":\"""$v_descriptionActivity""\"}})"

echo $v_descriptionActivity >> /tmp/yon
 mongo mongodb://127.0.0.1:27017/middlewarel2 --eval "$exp"
