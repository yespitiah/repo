import  mongoose from   'mongoose';
import  { Router } from 'express';
import  Account  from '../app/models/account';
import Entitlements  from '../app/models/entitlements';
import  bodyParser from  'body-parser';
import  passport from 'passport';
import  config   from  '../config';
import  Support  from '../app/models/support';

import  {generateAccessToken, respond, authenticate} from  '../middleware/authMiddleware';

export default ({ config, db }) => {
let api =  Router();
// '/v1/account'
api.get('/', (req, res)=>{
    res.status(200).send({ user: req.user });
});


// '/v1/account/entitlements'
api.post('/entitlements',(req, res) => {
var  v_soeid =  req.body.soeid;
console.log("entitlements->"+v_soeid);
Entitlements.find({soeid:v_soeid},(err,Entitlements)=>{
    if(err){
      res.send(err);
    }
    res.json(Entitlements);
});
});

// '/v1/account/regiterValidation'
api.post('/registerV',(req, res) => {
var  v_soeid =  req.body.soeid;
console.log("registerV->"+v_soeid);
Account.find({username:v_soeid},(err,Account)=>{
    if(err){
      res.send(err);
    }
    res.json(Account);
});
});

api.post('/resetPassword',(req, res) => {
var  v_soeid =  req.body.soeid;
var v_password = req.body.password;
console.log("resetPassword->"+v_soeid);
Account.remove({username:v_soeid},(err,Account)=>{
    if(err){
      res.send(err);
    }
    //res.json(Account);
});
Account.register(new Account({ username:  req.body.soeid}), req.body.password, function(err, account){
  if(err){
    //return res.status(500).send('An error occurred: ' +  err);
    res.send(err);
  }
  res.json(account);
  passport.authenticate(
    'local', {
      session: false })(req, res,() => {

        res.status(200).send('sucessfully created new  account');
      });
});
});
/////////

api.post('/username',(req, res) => {
var  v_soeid =  req.body.username;
//console.log("entitlements->"+v_soeid);
Entitlements.find({soeid:v_soeid},(err,Entitlements)=>{
    if(err){
      res.send(err);
    }
    console.log(Entitlements);

    res.json(Entitlements);
});
});


// '/v1/account/register'

api.post('/register', (req, res) => {
  //v_soeid=req.body.soeid;
  //console.log("register->"+v_soeid);

Account.register(new Account({ username:  req.body.soeid}), req.body.password, function(err, account){
  if(err){
    //return res.status(500).send('An error occurred: ' +  err);
    res.send(err);
  }
  res.json(account);
  passport.authenticate(
    'local', {
      session: false })(req, res,() => {

        res.status(200).send('sucessfully created new  account');
      });
});
});


//  '/v1/account/login'
api.post('/login', passport.authenticate(
  'local',{
    session: false,
    scope:[]
  }), generateAccessToken, respond);



// '/vi/account/logout'
api.get('/logout', authenticate, (req, res) =>{
req.logout();
res.status(200).send('Sucessfully logged out');
});

api.get('/me', authenticate, (req,res) =>{
  res.status(200).json(req.user);
});




return api;

}
