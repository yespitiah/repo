import  mongoose from   'mongoose';
import  { Router } from 'express';
import  Account  from '../app/models/account';
import  bodyParser from  'body-parser';
import  passport from 'passport';
import  config   from  '../config';
import  Support  from '../app/models/support';
import  Application  from '../app/models/application';
import  shell from '../node_modules/shelljs-master/shell.js';
import { authenticate }  from  '../middleware/authMiddleware';



export default ({ config, db }) => {
let api =  Router();
// '/v1/account'
api.get('/', (req, res)=>{
    res.status(200).send({ user: req.user });
});

//router.route('/listAlerts')
//api.get('/listAlerts', authenticate, (req, res) => {

api.get('/listAlerts', authenticate, (req, res) => {
   Support.find({type:"alert"}, (err, applicacion) =>{
     if(err){
       res.send(err);

     }
     res.json(applicacion);
   });
});

api.post('/openTicket',(req, res) => {
      var  support =  new  Support();
      support.soid   =  req.body.soid;
      support.topic  =  req.body.topic;
      support.tittle  =  req.body.title;
      support.description    =  req.body.description;
      support.ticket =  req.body.ticket;
      support.date =  new Date();

      support.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
      });
});



api.post('/updateAlerts',(req, res) => {
//db.supports.findOneAndUpdate({details:"something"},{$set:{soeids:[ "yonatan.espitia", "xochitldg","user.prueba" ]}})
var  v_details =  req.body.details;
var  v_soeids  =   req.body.soeids;
var  v_Array   =  v_soeids.split(",");
console.log("XY->"+v_details + v_soeids +','+ v_Array);
Support.findOneAndUpdate(
  { description:v_details },
  {$set:{soeids:v_soeids}},
  {safe: true, upsert: true},
  function(err, model) {
      console.log(err);
  });
});






      api.post('/AddTab', authenticate, (req, res) =>{

        var  application =  new  Application();

        var v_platform =  req.body.platform;
        var v_region   =  req.body.region;
        var v_name     =  req.body.app;
        var v_env      =  req.body.env;
        var v_tabName  =  req.body.Activity;
        var v_descriptionActivity= req.body.descriptionActivity;
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"->"+v_tabName+"->"+v_descriptionActivity);

        if(v_platform == "WEBSPHERE"){
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"->"+v_tabName+"->"+v_descriptionActivity);

         shell.exec('./shells/descriptionActivity.sh '+v_platform+' '+v_region+' '+v_name+' '+v_env+' '+v_tabName+' \"'+v_descriptionActivity+'\"')


        }else if (application.platform == "PCF") {

                console.log("PLATFORM"+application.platform);

        }else if (application.platform == "CLOUD") {
        }
        application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
        });
      });



            api.get('/application/:name',(req, res) =>{
              Application.distinct(req.params.name, function(err, application){
              if(err){
              res.send(err);

              }
              res.json(application);
              });
           });


           api.get('/application/regions/:name',(req, res)=> {
              Application.distinct('region', {platform:req.params.name}, function(err, applicacion){
                if(err){
                  res.send(err);

                }
                res.json(applicacion);
              });
           });



           api.get('/application/app/:platform/:region',(req, res) => {

              Application.distinct('name', { platform:req.params.platform,region:req.params.region}, function(err, applicacion){
                if(err){
                  res.send(err);

                }
                res.json(applicacion);
              });
           });



           api.get('/application/app/:platform/:region/:name/:env',(req, res) => {

              Application.find({platform:req.params.platform,region:req.params.region,name:req.params.name},{_id:0, envs:{$elemMatch: {env: req.params.env}}},function(err, applicacion){
                if(err){
                  res.send(err);

                }
                res.json(applicacion);
              });
           });


           api.get('/application/app/:platform/:region/:name',(req, res) =>{
              Application.distinct('envs.env', { platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
                if(err){
                  res.send(err);

                }
                res.json(applicacion);
              });
           });



           api.get('/application/app/:platform/:region/:name/action/:typeAction',(req, res) => {
           if ( req.params.typeAction == "desc") {
              //Application.distinct('envs.mainactivities.nameActivity', {platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
              //Application.find({platform:req.params.platform,region:req.params.region,name:req.params.name},{_id:0, envs:{$elemMatch: {env: req.params.env}}},function(err, applicacion){
              Application.distinct('envs.mainactivities', {platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
                if(err){
                  res.send(err);
                }
                res.json(applicacion);
              });
            }
           else if (req.params.typeAction == "app") {

              Application.distinct('envs.env', { platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
                if(err){
                  res.send(err);
                }
                res.json(applicacion);
              });
            }
           });

                 api.post('/AddApplications',(req, res) => {

                   var  application =  new  Application();
                   application.platform =  req.body.platform;
                   application.region   =  req.body.region;
                   application.name     =  req.body.name;
                   var SizeEnvs         =  req.body.envs.length;
                   if(application.platform == "WEBSPHERE"){

                    for (i = 1; i <= SizeEnvs; i++) {
                       //var json =
                       application.envs.push({
                         env: req.body.envs[(i-1)].env,
                         console: req.body.envs[(i-1)].console,
                         soid: req.body.envs[(i-1)].soid,
                         password: req.body.envs[(i-1)].password,
                         deploy: req.body.envs[(i-1)].deploy,
                         webHost: req.body.envs[(i-1)].webHost,
                         descripton: 'Write one custom process / playbook EX: ',
                         active:'yes'
                       });
                    }



                  }else if (application.platform == "PCF") {




                    for (i = 1; i <= SizeEnvs; i++) {

                      application.envs.push({
                      env: req.body.envs[(i-1)].env,
                      jumpBox: req.body.envs[(i-1)].jumpBox,
                      cfCLI: req.body.envs[(i-1)].cfCLI,
                      appMng:req.body.envs[(i-1)].appMng,
                      opMng: req.body.envs[(i-1)].opMng,
                      soidPCF: req.body.envs[(i-1)].soidPCF,
                      passwordPCF: req.body.envs[(i-1)].passwordPCF,
                      splunk: req.body.envs[(i-1)].splunk,
                      appD: req.body.envs[(i-1)].appD});


                    }
                  }else if (application.platform == "CLOUD") {
                  };
                 application.save(function(err){
                   if(err){
                     res.send(err);
                   }
                   res.json({message:' Was  sucessfull created'});
                 });
           });//POST

                 api.post('/AddEnvApplications',(req, res) => {

                   var  application =  new  Application();

                   var v_platform =  req.body.platform;
                   var v_region   =  req.body.region;
                   var v_name     =  req.body.app;
                   var v_env      =  req.body.env;
                   var v_console  =  req.body.console;
                   var v_soid     =  req.body.soid;
                   var v_password =  req.body.password;
                   var v_deploy  =   req.body.deploy;
                   var v_webHost =   req.body.webHost;
                   if(v_platform == "WEBSPHERE"){
                         Application.findOneAndUpdate(
                             { platform : v_platform, region : v_region , name:v_name},
                             {$push:{envs:{"env" : v_env, "console" : v_console, "soid" : v_soid, "password" : v_password, "deploy" : v_deploy, "webHost" : v_webHost, "descripton" : "Write one custom process / playbook EX: ", "active" : "yes" }}},
                             {safe: true, upsert: true},
                             function(err, model) {
                                 console.log(err);
                             }
                         );
                  }else if (application.platform == "PCF") {



                  }else if (application.platform == "CLOUD") {
                  };
                 application.save(function(err){
                   if(err){
                     res.send(err);
                   }
                   res.json({message:' Was  sucessfull created'});
                 });
           })//POST NO working



                 api.post('/UpdateApplicationDesc',(req, res) => {
                   var  application =  new  Application();
                   //{platform:v_platform,region:v_region,app:v_app,env:v_env,description:v_updateDescTxt}
                   var v_platforma =  req.body.platform;
                   var v_region   =  req.body.region;
                   var v_name     =  req.body.app;
                   var v_env      =  req.body.env;
                   var v_updateDescTxt  =  req.body.description;


                   if(v_platform == "WEBSPHERE"){
                   console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"-> Description:"+v_updateDescTxt);

                   Application.findOneAndUpdate(
                     {platform:"WEBSPHERE",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
                     {safe: true, upsert: true},
                     function(err, model) {
                     });
                     application.save(function(err){
                       if(err){
                         res.send(err);
                       }
                       res.json({message:' Was  sucessfull created'});
                     });

            }if(v_platform == "PCF"){
            console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"-> Description:"+v_updateDescTxt);

            Application.findOneAndUpdate(
              {platform:"PCF",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
              {safe: true, upsert: true},
              function(err, model) {
              });
              application.save(function(err){
                if(err){
                  res.send(err);
                }
                res.json({message:' Was  sucessfull created'});
              });

           }if(v_platform == "GEMFIRE"){
           console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"-> Description:"+v_updateDescTxt);


           Application.findOneAndUpdate(
             {platform:"GEMFIRE",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
             {safe: true, upsert: true},
             function(err, model) {
                 console.log(err);
               });
               application.save(function(err){
                 if(err){
                   res.send(err);
                 }
                 res.json({message:' Was  sucessfull created'});
               });
           }if(v_platform == "TOMCAT"){


           Application.findOneAndUpdate(
             {platform:"TOMCAT",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
             {safe: true, upsert: true},
             function(err, model) {
                 console.log(err);
             });
             application.save(function(err){
               if(err){
                 res.send(err);
               }
               res.json({message:' Was  sucessfull created'});
             });

           }



           })//POST


                 api.post('/UpdateMainactivitiesDesc', authenticate,(req, res) => {
                   var  application =  new  Application();
                   var v_platform =        req.body.platform;
                   var v_region   =        req.body.region;
                   var  v_name     =        req.body.app;
                   var v_env      =        req.body.env;
                   var v_updateDescTxt  =  req.body.description;
                   var v_number =          req.body.number;

                   if(v_platform == "WEBSPHERE"){


                    shell.exec('./shells/file.sh '+v_platform+' '+v_region+' '+v_name+' '+v_env+' '+v_number+' \"'+v_updateDescTxt+'\"')

            }else if (application.platform == "PCF") {



                  }else if (application.platform == "CLOUD") {
                  };
                 application.save(function(err){
                   if(err){
                     res.send(err);
                   }
                   res.json({message:' Was  sucessfull created'});
                 });



           })//POST




return api;

}
