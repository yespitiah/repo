import  http       from 'http';
import  express    from 'express';
import  bodyParser from 'body-parser';
import  mongoose   from 'mongoose';
import  config      from './config';
import  routes     from  './routes';
import  passport  from   'passport';
import  middleware from  './middleware';

const   LocalStrategy =  require ('passport-local').Strategy;
import  track  from    'express'
var shell =  require('./node_modules/shelljs-master/shell.js')
var Application =  require('./app/models/application');
var Support =  require('./app/models/support');
var Client = require('ssh2').Client;
var readline = require('readline');
var conn = new Client();
var connection = require('./js/connection.js');

let app = express();
app.server =  http.createServer(app);

//middleware
//parse applicacion/json
app.use(bodyParser.json({limit:config.bodyLimit}));

//data from the body of POST
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
let Account  = require ('./app/models/account');
passport.use(new LocalStrategy({
  usernameField: 'mail',
  passwordField: 'password'
},
Account.authenticate()
));

//passport config
passport.serializeUser(Account.serializeUser());
passport.deserializeUser(Account.deserializeUser());

//api routes v1
app.use('/',routes);
app.server.listen(config.port);
console.log(`Started on the port  ${app.server.address().port}`);
export default app;

/*
//Set up port for server listen on
var  port  =  process.env.PORT || 3000;

//Connectt  to  DB
mongoose.connect('mongodb://localhost:27017/middlewarel2')
*/
// API  ROUTES
/*
var router =  express.Router();


//Routers  will all  be  prefixed  with  /API

app.use('/action',  router);

//middleware validations, loging or  stop request if is not  safe
//use for  all request

router.use(function(req, res, next){
  console.log('There is some processing corrently going down...')
  next();
});





*/
/*







router.route('/AddTab')
//var cadena = {platform:v_platform,region=v_region,app=v_app,env=v_env,Activity:v_tabName,descriptionActivity:v_description};

      .post(function(req, res) {

        var  application =  new  Application();

        v_platform =  req.body.platform;
        v_region   =  req.body.region;
        v_name     =  req.body.app;
        v_env      =  req.body.env;
        v_tabName  =  req.body.Activity;
        v_descriptionActivity= req.body.descriptionActivity;
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"->"+v_tabName+"->"+v_descriptionActivity);
        //db.applications.findOneAndUpdate({"platform":"WEBSPHERE","region":"NAM","name":"43464_MARKETING","envs":{$elemMatch: {"env":"LOAD1"}}},{$push:{"envs.$.mainactivities":{"nameActivity" : "Game2","descriptionActivity" : "x"}}})
        //db.applications.findOneAndUpdate({"platform":"WEBSPHERE","region":"NAM","name":"43464_MARKETING","envs":{$elemMatch: {"env":"LOAD1"}}},{$push:{"envs.$.mainactivities":{"nameActivity" : "Game2","descriptionActivity" : "x"}}})

        if(v_platform == "WEBSPHERE"){
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"->"+v_tabName+"->"+v_descriptionActivity);

         shell.exec('./shells/descriptionActivity.sh '+v_platform+' '+v_region+' '+v_name+' '+v_env+' '+v_tabName+' \"'+v_descriptionActivity+'\"')


        }else if (application.platform == "PCF") {

                console.log("PLATFORM"+application.platform);

        }else if (application.platform == "CLOUD") {
        }
        application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
        });
      });


/*
        if(v_platform == "WEBSPHERE"){
              Application.findOneAndUpdate(
                  { platform : v_platform, region : v_region , name:v_name, envs:{$elemMatch: {env:v_env}}},{$push:{'envs.$.mainactivities':{nameActivity : v_tabName,descriptionActivity : v_descriptionActivity}}},
                  //{ platform:"WEBSPHERE",  region: "NAM",      name:v_name, envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
                  {safe: true, upsert: true},
                  function(err, model) {
                      console.log(err);
                  });
       }else if (application.platform == "PCF") {

                console.log("PLATFORM"+application.platform);

       }else if (application.platform == "CLOUD") {
       };
      application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
      });
})//POST
*/


/*






//U pdate  for  mainactivities json elements



router.route('/application/app/shell/:action/:appName/:hostName/:jvm/:num')
//router.route('/application/app/shell/:action')
.get(function(req, res) {

//console.log(req.params.action);

if ( req.params.action == "dumpThreads") {

var  appName =  req.params.appName;
var  hostNameDump = req.params.hostName;
var  jvmName =  req.params.jvm;
var  num    =   req.params.num;

    try{
      var Client = require('ssh2').Client;
      var readline = require('readline');
      var conn = new Client();
      var soid = "ye09463";
      var password = "C1t1b@nk37";
      var hostName = "olb-adm02";
      var cmd ='';

      //console.log(cmd);

       var f_shellDumpsConnect = function(appName,hostNameDump,cmd){
                         if (appName == 'CBOL') {
                           cmd = 'ssh  webmwadm@'+hostNameDump+' \'sh /home/webmwadm/scripts/wikil2_dumps.sh '+jvmName+' '+ num +'\' ';
                         }else if (appName == 'AO' || appName == 'BAO') {
                           cmd ="ssh  cb@"+ hostNameDump +" \'sh /home/cb/scripts/"+ appName +"/wikil2_dumps.sh "+ jvmName +" "+ num +"\'";
                         }

                           var result='';
                           var clean_string='';
                           var  i = 0;
                           var  c = '';
                   try{
                        conn.on('ready', function() {
                        conn.shell(function(err, stream) {if (err) throw conn.end();

                         stream.on('close', function() {conn.end(); });
                         stream.on('data', function(data) {
                           if (data.indexOf(':') >= data.length - 2) {
                            i = i +1;
                            if(i == 1){
                            stream.write(password+'\n');
                            }else if (i == 2) {
                            stream.write('dumpThreads\n');
                            stream.write(cmd+'\n');
                            i = i +1;
                            };};
                            console.log(String(data));
                            b=String(data);
                            c=b.replace(/[^a-zA-Z0-9]+/g,"");
                            if (c == 'completed') {
                           conn.end();
                           //console.log('ntro');
                            }
                            //console.log(String(data));
                         });
                          stream.stderr.on('data', function(data) {  });
                          stream.write('pbrun  webmwadm\n');
                     });
                     });

                   conn.on('keyboard-interactive', function (name, descr, lang, prompts, finish) {
                          return finish([password]);
                         });
                   conn.connect({
                       host: hostName,
                       port: 22,
                       username:soid,
                       tryKeyboard: true,
                         algorithms: {
                         kex:[
                             'diffie-hellman-group1-sha1'
                             ],
                     hostkey_algorithm:[
                        'ssh-rsa'
                       ],
                     hmac:[
                             'hmac-sha2-256',
                             'hmac-sha2-512',
                             'hmac-sha1',
                             'hmac-md5',
                             'hmac-sha2-256-96',
                             'hmac-sha2-512-96',
                             'hmac-ripemd160',
                             'hmac-sha1-96',
                             'hmac-md5-96'
                     ],
                       cipher: [
                             'aes128-cbc'
                         ],
                       hmac:[
                          'hmac-sha1'
                            ]
                       }
                     });

                    return(c);
                     }catch(error) {
                       return('Failed');

                   }

                   }

f_shellDumpsConnect(appName,hostNameDump,cmd);




    res.json({message:' Was  sucessfull created'});
  }catch(error) {
    res.json({message:error});
}
};


});



      router.route('/application/versionReport')
      //{"app":"153026_BAO","env":"LOAD","soid":"ye09463","password":"C1t1b@nk37","email":"yonatan.espitia@citi.com"}
                .post(function(req, res) {
                appName  = req.body.app,
                env      = req.body.env,
                soid     = req.body.soid,
                password = req.body.password,
                email    = req.body.email,
                cmd ="",
                i = 0

               console.log(appName);
                     if (appName=="153026_AO"){
              console.log("153026_AO");
               cmd ="ssh cb@aoap-lod3612 \'sh /home/cb/scripts/AO/wikil2_sendversionReport.sh "+email+"\'"
             }else if (appName=="153026_BAO") {
              console.log("153026_BAO");
               cmd ="ssh cb@aoap-lod3614 \'sh /home/cb/scripts/BAO/wikil2_sendversionReport.sh "+email+"\'"
             } else if (appName=="144564_CBOL") {
               cmd ="ssh webmwadm@gtcrd-cblla01q \'sh /home/webmwadm/scripts/CBOL/wikil2_sendversionReport.sh "+email+"\'"
               }
               var f_shellConnect = function(soid,hostName,password,cmd){
                     var result='';
                     var clean_string='';
                     var  i = 0;
                     var  c = '';
             try{
                  conn.on('ready', function() {
                  conn.shell(function(err, stream) {if (err) throw conn.end();

                   stream.on('close', function() {conn.end(); });
                   stream.on('data', function(data) {
                                                       if (data.indexOf(':') >= data.length - 2) {
                                                        i = i +1;
                                                        if(i == 1){
                                                        stream.write(password+'\n');
                                                        }else if (i == 2) {
                                                        stream.write('Version Report\n');
                                                        stream.write(cmd+'\n');
                                                        i = i +1;
                                                        };};
                                                        console.log(String(data));
                                                        b=String(data);
                                                        c=b.replace(/[^a-zA-Z0-9]+/g,"");
                                                        if (c == 'completed') {
                                                       conn.end();
                                                       console.log('ntro');
                                                        }
                                                        //console.log(String(data));
                                                     });

                   stream.stderr.on('data', function(data) {  });
                   stream.write('pbrun  webmwadm\n');
               });
               });

             conn.on('keyboard-interactive', function (name, descr, lang, prompts, finish) {
                    return finish([password]);
                   });
             conn.connect({
                 host: hostName,
                 port: 22,
                 username:soid,
                 tryKeyboard: true,
                   algorithms: {
                   kex:[
                       'diffie-hellman-group1-sha1'
                       ],
               hostkey_algorithm:[
                  'ssh-rsa'
                 ],
               hmac:[
                       'hmac-sha2-256',
                       'hmac-sha2-512',
                       'hmac-sha1',
                       'hmac-md5',
                       'hmac-sha2-256-96',
                       'hmac-sha2-512-96',
                       'hmac-ripemd160',
                       'hmac-sha1-96',
                       'hmac-md5-96'
               ],
                 cipher: [
                       'aes128-cbc'
                   ],
                 hmac:[
                    'hmac-sha1'
                      ]
                 }
               });

              return(c);
               }catch(error) {
                 return('Failed');

             }

             }

f_shellConnect(soid,'olb-adm02',password,cmd);

});
*/
/*
//Fire up  server
app.listen(port);

// Print   message to console
console.log('Server express started on portor ' + port);
*/
