var express =  require('express');
var app =   express();
var track =   express();
var bodyParser =  require('body-parser');
var mongoose =  require('mongoose');
var shell =  require('./node_modules/shelljs-master/shell.js')
var Application =  require('./app/models/application');
var Support =  require('./app/models/support');
//var Support =  require('./app/models/tracker');


//data from the body of POST

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

//Set up port for server listen on
var  port  =  process.env.PORT || 3000;

//Connectt  to  DB
mongoose.connect('mongodb://localhost:27017/middlewarel2')

// API  ROUTES

var router =  express.Router();


//Routers  will all  be  prefixed  with  /API

app.use('/action',  router);

//middleware validations, loging or  stop request if is not  safe
//use for  all request

router.use(function(req, res, next){
  console.log('There is some processing corrently going down...')
  next();
});

//Test  Routers

router.get('/', function(req,res){
res.json({message: 'Middleware L2 API!'});
});

//SUPPORT
router.route('/openTicket')

      .post(function(req, res) {
      var  support =  new  Support();
      support.soid   =  req.body.soid;
      support.topic  =  req.body.topic;
      support.tittle  =  req.body.title;
      support.description    =  req.body.description;
      support.ticket =  req.body.ticket;
      support.date =  new Date();

      support.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
      });
})//POST


router.route('/AddApplications')

      .post(function(req, res) {

        var  application =  new  Application();
        application.platform =  req.body.platform;
        application.region   =  req.body.region;
        application.name     =  req.body.name;
        var SizeEnvs         =  req.body.envs.length;
        if(application.platform == "WEBSPHERE"){

         for (i = 1; i <= SizeEnvs; i++) {
            //var json =
            application.envs.push({
              env: req.body.envs[(i-1)].env,
              console: req.body.envs[(i-1)].console,
              soid: req.body.envs[(i-1)].soid,
              password: req.body.envs[(i-1)].password,
              deploy: req.body.envs[(i-1)].deploy,
              webHost: req.body.envs[(i-1)].webHost,
              descripton: 'Write one custom process / playbook EX: ',
              active:'yes'
            });
         }
           console.log(application);


       }else if (application.platform == "PCF") {

         console.log("ENTRO PCF");


         for (i = 1; i <= SizeEnvs; i++) {

           application.envs.push({
           env: req.body.envs[(i-1)].env,
           jumpBox: req.body.envs[(i-1)].jumpBox,
           cfCLI: req.body.envs[(i-1)].cfCLI,
           appMng:req.body.envs[(i-1)].appMng,
           opMng: req.body.envs[(i-1)].opMng,
           soidPCF: req.body.envs[(i-1)].soidPCF,
           passwordPCF: req.body.envs[(i-1)].passwordPCF,
           splunk: req.body.envs[(i-1)].splunk,
           appD: req.body.envs[(i-1)].appD});

           console.log("Entro push")
         }
       }else if (application.platform == "CLOUD") {
       };
      application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
      });
})//POST


router.route('/AddEnvApplications')

      .post(function(req, res) {

        var  application =  new  Application();

        v_platform =  req.body.platform;
        v_region   =  req.body.region;
        v_name     =  req.body.app;
        v_env      =  req.body.env;
        v_console  =  req.body.console;
        v_soid     =  req.body.soid;
        v_password =  req.body.password;
        v_deploy  =   req.body.deploy;
        v_webHost =   req.body.webHost;
        if(v_platform == "WEBSPHERE"){
              Application.findOneAndUpdate(
                  { platform : v_platform, region : v_region , name:v_name},
                  {$push:{envs:{"env" : v_env, "console" : v_console, "soid" : v_soid, "password" : v_password, "deploy" : v_deploy, "webHost" : v_webHost, "descripton" : "Write one custom process / playbook EX: ", "active" : "yes" }}},
                  {safe: true, upsert: true},
                  function(err, model) {
                      console.log(err);
                  }
              );
       }else if (application.platform == "PCF") {

                console.log("PLATFORM"+application.platform);

       }else if (application.platform == "CLOUD") {
       };
      application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
      });
})//POST



router.route('/AddTab')
//var cadena = {platform:v_platform,region=v_region,app=v_app,env=v_env,Activity:v_tabName,descriptionActivity:v_description};

      .post(function(req, res) {

        var  application =  new  Application();

        v_platform =  req.body.platform;
        v_region   =  req.body.region;
        v_name     =  req.body.app;
        v_env      =  req.body.env;
        v_tabName  =  req.body.Activity;
        v_descriptionActivity= req.body.descriptionActivity;
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"->"+v_tabName+"->"+v_descriptionActivity);
        //db.applications.findOneAndUpdate({"platform":"WEBSPHERE","region":"NAM","name":"43464_MARKETING","envs":{$elemMatch: {"env":"LOAD1"}}},{$push:{"envs.$.mainactivities":{"nameActivity" : "Game2","descriptionActivity" : "x"}}})
        //db.applications.findOneAndUpdate({"platform":"WEBSPHERE","region":"NAM","name":"43464_MARKETING","envs":{$elemMatch: {"env":"LOAD1"}}},{$push:{"envs.$.mainactivities":{"nameActivity" : "Game2","descriptionActivity" : "x"}}})

        if(v_platform == "WEBSPHERE"){
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"->"+v_tabName+"->"+v_descriptionActivity);

         shell.exec('./shells/descriptionActivity.sh '+v_platform+' '+v_region+' '+v_name+' '+v_env+' '+v_tabName+' \"'+v_descriptionActivity+'\"')


        }else if (application.platform == "PCF") {

                console.log("PLATFORM"+application.platform);

        }else if (application.platform == "CLOUD") {
        }
        application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
        });
      });


/*
        if(v_platform == "WEBSPHERE"){
              Application.findOneAndUpdate(
                  { platform : v_platform, region : v_region , name:v_name, envs:{$elemMatch: {env:v_env}}},{$push:{'envs.$.mainactivities':{nameActivity : v_tabName,descriptionActivity : v_descriptionActivity}}},
                  //{ platform:"WEBSPHERE",  region: "NAM",      name:v_name, envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
                  {safe: true, upsert: true},
                  function(err, model) {
                      console.log(err);
                  });
       }else if (application.platform == "PCF") {

                console.log("PLATFORM"+application.platform);

       }else if (application.platform == "CLOUD") {
       };
      application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
      });
})//POST
*/





router.route('/UpdateApplicationDesc')

      .post(function(req, res) {
        var  application =  new  Application();
        //{platform:v_platform,region:v_region,app:v_app,env:v_env,description:v_updateDescTxt}
        v_platform =  req.body.platform;
        v_region   =  req.body.region;
        v_name     =  req.body.app;
        v_env      =  req.body.env;
        v_updateDescTxt  =  req.body.description;

        //db.applications.update({platform:"WEBSPHERE",region:"NAM",name:"CBOL",envs:{$elemMatch: {env: "QA1"}}},{$set:{'envs.$.descripton':"QA10"}});
        if(v_platform == "WEBSPHERE"){
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"-> Description:"+v_updateDescTxt);

        //Application.findOneAndUpdate({platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
        //application.update({ platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
       //db.applications.update({platform:"WEBSPHERE",region:"NAM",name:"CBOL",envs:{$elemMatch: {env: "QA2"}}},{$set:{'envs.$.descripton':"QA10"}})
        Application.findOneAndUpdate(
          {platform:"WEBSPHERE",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
          {safe: true, upsert: true},
          function(err, model) {
          });
          application.save(function(err){
            if(err){
              res.send(err);
            }
            res.json({message:' Was  sucessfull created'});
          });

 }if(v_platform == "PCF"){
 console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"-> Description:"+v_updateDescTxt);

 //Application.findOneAndUpdate({platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
 //application.update({ platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
//db.applications.update({platform:"WEBSPHERE",region:"NAM",name:"CBOL",envs:{$elemMatch: {env: "QA2"}}},{$set:{'envs.$.descripton':"QA10"}})
 Application.findOneAndUpdate(
   {platform:"PCF",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
   {safe: true, upsert: true},
   function(err, model) {
   });
   application.save(function(err){
     if(err){
       res.send(err);
     }
     res.json({message:' Was  sucessfull created'});
   });

}if(v_platform == "GEMFIRE"){
console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"-> Description:"+v_updateDescTxt);

//Application.findOneAndUpdate({platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
//application.update({ platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
//db.applications.update({platform:"WEBSPHERE",region:"NAM",name:"CBOL",envs:{$elemMatch: {env: "QA2"}}},{$set:{'envs.$.descripton':"QA10"}})
Application.findOneAndUpdate(
  {platform:"GEMFIRE",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
  {safe: true, upsert: true},
  function(err, model) {
      console.log(err);
    });
    application.save(function(err){
      if(err){
        res.send(err);
      }
      res.json({message:' Was  sucessfull created'});
    });
}if(v_platform == "TOMCAT"){
console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"-> Description:"+v_updateDescTxt);

//Application.findOneAndUpdate({platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
//application.update({ platform:v_platform,region:v_region,name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.description':v_updateDescTxt}});
//db.applications.update({platform:"WEBSPHERE",region:"NAM",name:"CBOL",envs:{$elemMatch: {env: "QA2"}}},{$set:{'envs.$.descripton':"QA10"}})
Application.findOneAndUpdate(
  {platform:"TOMCAT",region:"NAM",name:v_name,envs:{$elemMatch: {env: v_env}}},{$set:{'envs.$.descripton':v_updateDescTxt}},
  {safe: true, upsert: true},
  function(err, model) {
      console.log(err);
  });
  application.save(function(err){
    if(err){
      res.send(err);
    }
    res.json({message:' Was  sucessfull created'});
  });

}



})//POST



//U pdate  for  mainactivities json elements

router.route('/UpdateMainactivitiesDesc')

      .post(function(req, res) {
        var  application =  new  Application();
        //{platform:v_platform,region:v_region,app:v_app,env:v_env,description:v_updateDescTxt}
        v_platform =        req.body.platform;
        v_region   =        req.body.region;
        v_name     =        req.body.app;
        v_env      =        req.body.env;
        v_updateDescTxt  =  req.body.description;
        v_number =          req.body.number;






        if(v_platform == "WEBSPHERE"){
        console.log(v_platform+"->"+v_region+"->"+v_name+"->"+v_env+"->"+v_updateDescTxt+"->"+v_number);

         shell.exec('./shells/file.sh '+v_platform+' '+v_region+' '+v_name+' '+v_env+' '+v_number+' \"'+v_updateDescTxt+'\"')

 }else if (application.platform == "PCF") {

                console.log("PLATFORM"+application.platform);

       }else if (application.platform == "CLOUD") {
       };
      application.save(function(err){
        if(err){
          res.send(err);
        }
        res.json({message:' Was  sucessfull created'});
      });



})//POST




























/*\
db.test.update({
  'classes.someClass.students' : {
     $elemMatch: {
       'name' : 'Jack'
     }
   }
}, {
  '$set' : {
    'classes.someClass.students.$.coolness' : 9
   }
});


{
    "name" : "someSchool",
    "classes" : {
            "someClass" : {
                    "students" : [
                            {
                                    "name" : "Jack",
                                    "coolness" : 7
                            }
                    ]
            }
    }
}



.post(function(req, res) {

  var  application =  new  Application();
  application.platform =  req.body.platform;
  application.region   =  req.body.region;
  application.name     =  req.body.name;
  var SizeEnvs         =  req.body.envs.length;

application.save(function(err){
  if(err){
    res.send(err);
  }
  res.json({message:' Was  sucessfull created'});
});
})//POST
*/



















//Getting AccessTickets
/*
  router.route('/AccessTicketsCloud')
       .get(function(req, res){
        Application.distinct(, function(err, application){
        if(err){
        res.send(err);

        }
        res.json(AccessTicketsCloud);
        });
     });*/

     router.route('/application/:name')
           .get(function(req, res){
             Application.distinct(req.params.name, function(err, application){
             if(err){
             res.send(err);

             }
             res.json(application);
             });
          });
    //http://127.0.0.1:3000/api/application/regions/GEMFIRE
     router.route('/application/regions/:name')
     .get(function(req, res) {
        Application.distinct('region', {platform:req.params.name}, function(err, applicacion){
          if(err){
            res.send(err);

          }
          res.json(applicacion);
        });
     });
    //http://127.0.0.1:3000/action/application/app/PCF/MEX
     router.route('/application/app/:platform/:region')

     .get(function(req, res) {
       //db.applications.distinct('name',{ platform:req.params.platform,region:req.params.region})
       console.log(req.params.platform+" "+req.params.region);
        Application.distinct('name', { platform:req.params.platform,region:req.params.region}, function(err, applicacion){
          if(err){
            res.send(err);

          }
          res.json(applicacion);
        });
     });

     //http://127.0.0.1:3000/action/application/app/PCF/MEX/55555
      router.route('/application/app/:platform/:region/:name')
      .get(function(req, res) {
         Application.distinct('envs.env', { platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
           if(err){
             res.send(err);

           }
           res.json(applicacion);
         });
      });
      //http://127.0.0.1:3000/action/application/app/PCF/MEX/55555
       router.route('/application/app/:platform/:region/:name/:env')
       .get(function(req, res) {
          //Application.find().distinct('envs._id', { name:req.params.name}).count(, function(err, applicacion){
          Application.find({platform:req.params.platform,region:req.params.region,name:req.params.name},{_id:0, envs:{$elemMatch: {env: req.params.env}}},function(err, applicacion){
            if(err){
              res.send(err);

            }
            res.json(applicacion);
          });
       });
      router.route('/application/app/:platform/:region/:name/action/:typeAction')
      .get(function(req, res) {
      if ( req.params.typeAction == "desc") {
         //Application.distinct('envs.mainactivities.nameActivity', {platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
         //Application.find({platform:req.params.platform,region:req.params.region,name:req.params.name},{_id:0, envs:{$elemMatch: {env: req.params.env}}},function(err, applicacion){
         Application.distinct('envs.mainactivities', {platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
           if(err){
             res.send(err);
           }
           res.json(applicacion);
         });
       }
      else if (req.params.typeAction == "app") {

         Application.distinct('envs.env', { platform:req.params.platform,region:req.params.region,name:req.params.name}, function(err, applicacion){
           if(err){
             res.send(err);
           }
           res.json(applicacion);
         });
       }
      });
//Fire up  server
app.listen(port);

// Print   message to console
console.log('Server express started on portor ' + port);
