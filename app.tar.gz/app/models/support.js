var  mongoose  =  require('mongoose');
var  Schema =  mongoose.Schema;

var osrSchema =  new Schema({

  soid: String,
  topic: String,
  tittle: String,
  description: String,
  ticket:String,
  date:String,
  type: String,
  time:String,
  active:String,
  details:String,
  soeids: [{
    type: String
}]
})
module.exports =   mongoose.model('support',osrSchema);
