var  mongoose  =  require('mongoose');
var  Schema =  mongoose.Schema;


var  sshHostInvSchema =   new  Schema({
 host:String;
 alias:String;
 fid:String;
 sshkey:String;
})

module.exports =   mongoose.model('sshHostInv',sshHostInvSchema);
