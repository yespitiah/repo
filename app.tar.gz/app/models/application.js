var  mongoose  =  require('mongoose');
var  Schema =  mongoose.Schema;


var mainactivitiesSchema = new Schema({
          nameActivity: String,
          descriptionActivity: String
})

var envSchema = new Schema({
  env: String,
  console: String,
  console1: String,
  soid: String,
  password: String,
  webHost:String,
  deploy:String,
  descripton:String,
  description:String,
  jumpBox:String,
  cfCLI:String,
  appMng:String,
  opMng:String,
  splunk:String,
  appD:String,
  AppDController:String,
  active:String
})


var appSchema = new Schema({
  platform: String,
  region: String,
  name:  String,
  envs: [envSchema],
  mainactivities: [mainactivitiesSchema]
})

module.exports =   mongoose.model('application',appSchema);
